$().ready(function() {

    // Atribui a função de validação do jQuery Validate ao formulário de id form-contato
    $('#form-contato').validate({
        // O rules é utilizado para expecificarmos qual campo desejamos validar
            rules:{
                // Informando que o campo nome precisa ser validado
                nome:{
                    // Informando que o campo é obrigatório e não pode ficar em branco
                    required: true,
                    // Informando que a quantidade minima para esse campo são 3 caracteres
                    minlength: 3
                },
                telefone:{
                    // Informando que o campo é obrigatório e não pode ficar em branco
                    required: true,
                    // Informando que a quantidade minima para esse campo são 9 caracteres
                    minlength: 9
                },

                assunto:{
                    // Informando que o campo é obrigatório e não pode ficar em branco
                    required: true,
                    // Informando que a quantidade minima para esse campo são 10 caracteres
                    minlength: 10,
                    // Informando que a quantidade máxima para esse campo são 100 caracteres
                    maxlength: 100
                },
            },
            messages:{
                nome:{
                    // Informa a mensagem de required a ser exibida
                    required: "O campo nome é obrigatorio.",
                    // Informa a mensagem de minlength a ser exibida
                    minlength: "O campo nome deve conter no mínimo 3 caracteres."
                },
                telefone:{
                    // Informa a mensagem de required a ser exibida
                    required: "O campo telefone é obrigatorio.",
                    // Informa a mensagem de minlength a ser exibida
                    minlength: "O campo telefone deve conter no mínimo 9 caracteres."
                },
                assunto:{
                    // Informa a mensagem de required a ser exibida
                    required: "O campo assunto é obrigatorio.",
                    // Informa a mensagem de minlength a ser exibida
                    minlength: "O campo assunto deve conter no mínimo 10 caracteres.",
                    // Informa a mensagem de maxlenght a ser exibida
                    maxlength: "O campo assunto deve conter no máximo 100 caracteres."
                },
            }
        });

});